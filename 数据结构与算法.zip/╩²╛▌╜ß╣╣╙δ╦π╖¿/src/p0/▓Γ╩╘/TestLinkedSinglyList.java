package p0.测试;

import p3.链式结构.LinkedSinglyCircularList;
import p3.链式结构.LinkedSinglyList;

import java.util.Comparator;

public class TestLinkedSinglyList {
    public static void main(String[] args) {
        LinkedSinglyCircularList<Integer> list = new LinkedSinglyCircularList<>();
        for (int i = 1; i <= 10; i++) {
            list.add((int) (Math.random() * 100));
        }
        System.out.println(list);
        list.sort(new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return o1 - o2;
            }
        });
        System.out.println(list);
        list.clear();
        for (int i = 1; i <= 41 ; i++) {
            list.add(i);
        }
        list.josephusLoop();
        System.out.println(list);
    }
}
