package p0.测试;

import p2.线性结构.ArrayDoubleEndStack;

public class TestArrayDoubleEndStack {
    public static void main(String[] args) {
        ArrayDoubleEndStack<Integer> stack01 = new ArrayDoubleEndStack<>();
        System.out.println(stack01);
        for (int i = 0; i < 10; i++) {
            stack01.pushLeft(i);
        }
        System.out.println(stack01);

        ArrayDoubleEndStack<Integer> stack02 = new ArrayDoubleEndStack<>();
        System.out.println(stack02);
        for (int i = 0; i < 10; i++) {
            stack02.pushRight(i);
        }
        System.out.println(stack02);



        ArrayDoubleEndStack<Integer> stack03 = new ArrayDoubleEndStack<>();
        System.out.println(stack03);
        for (int i = 0; i < 10; i++) {
            stack03.pushRight(i);
            stack03.pushLeft(i);
        }
        System.out.println(stack03);

        for (Integer num : stack03){
            System.out.println(num);
        }
    }
}
