package p0.测试;

import p2.线性结构.ArrayStack;

public class TestArrayStack {
    public static void main(String[] args) {
        ArrayStack<Integer> stack01 = new ArrayStack<>();
        ArrayStack<Integer> stack02 = new ArrayStack<>(15);
        for (int i = 1; i <= 12; i++){
            stack01.push(i);
            stack02.push(i);
        }
        System.out.println(stack01);
        System.out.println(stack02);
        System.out.println(stack01.equals(stack02));


        System.out.println(stack01.pop());
        System.out.println(stack01);
        System.out.println(stack01.peek());
    }
}
