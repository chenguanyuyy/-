package p0.测试;

import p2.线性结构.ArrayList;

import java.util.Comparator;
import java.util.Iterator;
import java.util.Random;

public class TestArrayList {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        System.out.println(list);
        Random random = new Random();
        for (int i = 0; i < 10; i++){
            list.add(random.nextInt(100));
        }
        System.out.println(list);


        for (int i = 0; i < 10; i++){
            list.add(0 ,i);
        }
        System.out.println(list);

        list.sort(new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return o1 - o2;
            }
        });
        System.out.println(list);

        for (Integer num : list){
            System.out.println(num);
        }

        Iterator<Integer> it = list.iterator();
        while (it.hasNext()){
            System.out.print(it.next() + " ");
        }
    }
}
