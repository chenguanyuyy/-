package p1.接口;
//队列
public interface Queue<E> extends Iterable<E> {
    //入队
    public void offer(E element);
    //出队
    public E poll();
    //查看队首元素
    public E element();
    //判断是否为空
    public boolean isEmpty();
    //清空
    public void clear();
    //获取元素个数
    public int size();
}
