package p2.线性结构;

import java.util.HashMap;

//括号匹配
public class MatchBracket {
    public static void main(String[] args) {
        solution01();
        solution02();
    }

    private static void solution01() {
        String str = "{(<>)[][][()]}";
        ArrayStack<Character> stack = new ArrayStack<>();
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (stack.isEmpty()) {
                stack.push(c);
            } else {
                char top = stack.peek();
                if (top - c == -1 || top - c == -2){
                    stack.pop();
                } else {
                    stack.push(c);
                }
            }
        }
        System.out.println(stack.isEmpty());
    }

    //HashMap
    private static void solution02() {
        String str = "{(<>)[]{[]}[()]}";
        HashMap<Character,Character> map = new HashMap<>();
        map.put('(',')');
        map.put('<','>');
        map.put('[',']');
        map.put('{','}');
        ArrayStack<Character> stack = new ArrayStack<>();
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (stack.isEmpty()) {
                stack.push(c);
            } else {
                char top = stack.peek();
                if (map.containsKey(top) && c == map.get(top)){
                    stack.pop();
                } else {
                    stack.push(c);
                }
            }
        }
        System.out.println(stack.isEmpty());
    }
}
