package p2.线性结构;

import java.util.Iterator;

//双端栈
public class ArrayDoubleEndStack<E> implements Iterable<E>{

    //左端栈的栈顶
    private int ltop;
    //右端栈的栈顶
    private  int rtop;
    //存储元素的容器
    private  E[] data;
    //数组容器的默认容量
    private static int DEFAULT_CAPACITY = 10;

    public ArrayDoubleEndStack(){
        data = (E[]) new Object[DEFAULT_CAPACITY];
        ltop = -1;
        rtop = data.length;
    }

    /**
     *    元素进栈
     */
    //左端进栈元素
    public void pushLeft(E element){
        if (ltop + 1 == rtop) {         //判断是否已满
            resize(data.length * 2);
        }
        //ltop++;
        data[++ltop] = element;
    }

    //右端进栈元素
    public void pushRight(E element){
        if (ltop + 1 == rtop) {         //判断是否已满
            resize(data.length * 2);
        }
        data[--rtop] = element;
    }

    /**
     *    扩容/缩容
     */
    //扩容
    private void resize(int newLen) {
        E[] newData  = (E[]) new Object[newLen];
        //复制左端栈的元素
        for (int i = 0; i <= ltop; i++) {
            newData[i] = data[i];
        }
        //复制右端栈的元素
        int index = rtop;
        for (int i = newLen - sizeRight(); i < newLen; i++) {
            newData[i] = data[index++];
        }
        //更新rtop
        rtop = newLen - sizeRight();
        //数组重定向
        data = newData;
    }

    /**
     *    出栈
     */
    //左端出栈
    public E popLeft(){
        if (isLeftEmpty()) {
            throw new IllegalArgumentException("left stack is null");
        }
        E ret = data[ltop--];
        if (sizeLeft() + sizeRight() <= data.length / 4 && data.length > DEFAULT_CAPACITY) {
            resize(data.length / 2);  //缩容
        }
        return ret;
    }

    //右端出栈
    public E popRight(){
        if (isRightEmpty()) {
            throw new IllegalArgumentException("right stack is null");
        }
        E ret = data[rtop++];
        if (sizeLeft() + sizeRight() <= data.length / 4 && data.length > DEFAULT_CAPACITY) {
            resize(data.length / 2);  //缩容
        }
        return ret;
    }

    /**
     *    获取栈顶元素
     */
    //左端栈顶
    public E peekLeft(){
        if (isLeftEmpty()) {
            throw new IllegalArgumentException("left stack is null");
        }
        return data[ltop];
    }

    //右端栈顶
    public E peekRight(){
        if (isRightEmpty()) {
            throw new IllegalArgumentException("right stack is null");
        }
        return data[rtop];
    }

    /**
     *    判断是否为空
     */
    //判断左端是否为空
    public boolean isLeftEmpty(){
        return ltop == -1;
    }

    //判断右端是否为空
    public boolean isRightEmpty(){
        return rtop == data.length;
    }

    /**
     *    获取元素个数
     */
    //左端元素个数
    public int sizeLeft(){
        return ltop + 1;
    }

    //右端元素个数
    public int sizeRight(){
        return data.length - rtop;
    }


    //打印字符串形式
    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append('[');
        if (isLeftEmpty() && isRightEmpty()) {
            sb.append(']');
            return sb.toString();
        }
        //先搞左边
        for (int i = 0; i <= ltop ; i++) {
            sb.append(data[i]);
            if (i == ltop && isRightEmpty()) {
                sb.append(']');
                return sb.toString();
            }else {
                sb.append(',');
            }
        }
        //后搞右边
        for (int i = 0; i < data.length ; i++) {
            sb.append(data[i]);
            if (i == data.length - 1){
                sb.append(']');
            } else {
                sb.append(',');
            }
        }
        return sb.toString();
    }

    @Override
    public Iterator<E> iterator() {
        return new ArrayDoubleEndStackIterator();
    }

    /**
     *    迭代器
     */
    class ArrayDoubleEndStackIterator implements Iterator<E>{
        //存储容器
        private ArrayList<E> list;
        private  Iterator<E> it;

        public ArrayDoubleEndStackIterator(){
            list = new ArrayList<>();

            for (int i = 0; i <= ltop; i++) {
                list.add(data[i]);
            }
            for (int i = rtop; i < data.length; i++) {
                list.add(data[i]);
            }
            it = list.iterator();
        }
        
        @Override
        public boolean hasNext() {
            return it.hasNext();
        }

        @Override
        public E next() {
            return it.next();
        }
    }
}
