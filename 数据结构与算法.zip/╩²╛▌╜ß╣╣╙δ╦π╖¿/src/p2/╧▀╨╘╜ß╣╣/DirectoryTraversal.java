package p2.线性结构;

import java.io.File;

//文件夹遍历
public class DirectoryTraversal {
    public static void main(String[] args) {
        File dir = new File("C:\\Users\\瑜\\Desktop\\数据结构与算法");
        ArrayDequeue<File> queue = new ArrayDequeue<>();
        queue.offer(dir);


        /*
        只要队列不为空，则出队一个目录对象
        将该目录对象展开 开始遍历 遇到文件则打印名称 遇到其他目录 则进队
         */
        while (!queue.isEmpty()){
            File file = queue.pop();
            System.out.println("【" + file.getName() + "】");
            File[] files = file.listFiles();
            for (File f : files) {
                if (f.isFile()) {
                    System.out.println(f.getName());
                } else {
                    queue.offer(f);
                }
            }
        }
    }
}
