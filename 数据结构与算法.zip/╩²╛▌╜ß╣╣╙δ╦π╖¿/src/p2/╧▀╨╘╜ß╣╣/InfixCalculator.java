package p2.线性结构;
//中缀表达式计算器
public class InfixCalculator {
    public static void main(String[] args) {

        String expression = "(10+20/2*3)/2+8";

        try {
            int result = evaluateExpression(expression);
            System.out.println(result);
        } catch (Exception e){
            e.printStackTrace();
            System.out.println("Wrong expression :" + expression);
        }

        
    }

    private static int evaluateExpression(String expression) {
        //需要两个辅助栈结构
        ArrayStack<Character> opratorStack = new ArrayStack<>();   //存操作符
        ArrayStack<Integer> numberStack = new ArrayStack<>();     //存数字

        //格式化表达式
        expression = insertBlanks(expression);
        //System.out.println(expression);
        String[] tokens = expression.split(" ");
        /*
        打印调试
        for (int i = 0; i < tokens.length; i++) {
            System.out.println("\"" + tokens[i] + "\"");
        }
         */
        for (String token : tokens) {  //token == tokens[i]
            //过滤空串
            if (token.length() == 0) {
                continue;

                //遍历到 + - 号
            } else if (token.equals("+") || token.equals("-")) {
                while (!opratorStack.isEmpty() && (opratorStack.peek() == '+' || opratorStack.peek() == '-' || opratorStack.peek() == '*' || opratorStack.peek() == '/')) {
                    //如果之前是别的+-*/ 需要弹栈 并计算
                    processAnOperator(numberStack, opratorStack);
                }
                //如果操作符栈为空 或者 不为空 但栈顶为(
                opratorStack.push(token.charAt(0));

                //遍历到 * / 号
            } else if (token.equals("*") || token.equals("/")) {
                while (!opratorStack.isEmpty() && (opratorStack.peek() == '*' || opratorStack.peek() == '/')) {
                    //如果之前是别的 * / 需要弹栈 并计算
                    processAnOperator(numberStack, opratorStack);
                }
                //如果操作符栈为空 或者 不为空 但栈顶为(
                opratorStack.push(token.charAt(0));

                //遍历到 (
            } else if (token.equals("(")) {
                opratorStack.push(token.charAt(0));

                //遍历到 )
            } else if (token.equals(")")) {
                //只要栈顶不是左括号( 挨个弹栈即可
                while (opratorStack.peek() != '('){
                    processAnOperator(numberStack, opratorStack);
                }
                //最后 清掉左括号(
                opratorStack.pop();

                //遍历数字
            } else {
                numberStack.push(Integer.parseInt(token)); //数字字符串解析成数字
            }
        }
        //处理最后面的操作符
        while(!opratorStack.isEmpty()){
            processAnOperator(numberStack, opratorStack);
        }
        return numberStack.pop();
    }

    //操作符栈弹栈的一个元素 数字栈弹栈两个数字 进行计算 并将新的结果进栈到数字栈
    private static void processAnOperator(ArrayStack<Integer> numberStack, ArrayStack<Character> opratorStack) {
        char op = opratorStack.pop();
        int num1 = numberStack.pop();
        int num2 = numberStack.pop();

        //顺序应为num2 op num1
        if (op == '+') {
            numberStack.push(num2 + num1);
        } else if (op == '-') {
            numberStack.push(num2 - num1);
        } else if (op == '*') {
            numberStack.push(num2 * num1);
        } else {
            numberStack.push(num2 / num1);
        }
    }

    //对原表达式进行格式化处理 给所有的非数字字符的两边添加空格
    private static String insertBlanks(String expression){
        /*
        "(10+20/2*3)/2+8"
         i
        " ( 10 + 20 / 2 * 3) / 2 + 8"
        */
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);
            if (c == '(' || c == ')' || c == '+' || c =='-' || c == '*' || c == '/') {
                sb.append(' ');
                sb.append(c);
                sb.append(' ');
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
